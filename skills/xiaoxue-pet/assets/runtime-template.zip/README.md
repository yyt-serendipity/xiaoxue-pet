# 人物照片桌宠项目

此目录由小薛同学桌宠 skill 初始化。人物原画尚未生成，必须按 skill 的素材契约制作、检查和编译后再启动。

1. 使用 skill 的照片流程生成完整角色、三视图及动作图集；不要把输入真人照片放入公开仓库。
2. 安装 requirements.txt；离线构建工具按 asset-build-requirements.txt 安装到 .asset-build-tools。
3. 运行 skill 的 validate_art.py --stage raw，再运行 prepare_assets.py。
4. 运行 validate_art.py --stage prepared --make-icon 生成当前人物图标，再用 render_preview.py 查看动作。
5. 运行 python -m unittest discover -p "test_*.py" -q；python main.py 启动。
6. Windows 下安装 requirements-build.txt，运行 scripts/build_release.py 和 scripts/verify_release.py。

包含轻量完整人物动画、简单陪伴操作、30 分钟看书专注、提醒和自动避让。图像生成只在制作时进行；普通桌宠不需要 Key，DeepSeek Key 只用于可选文字聊天。

本项目使用独立应用 ID XiaoxuePet，安装版数据在 %LOCALAPPDATA%\XiaoxuePet。源码版数据在本目录；不要公开 config.json 和 companion-state.json。不含预置人物、Key、个人配置或输入照片。

bootstrap 后显示名与应用 ID 已按新项目替换，源代码中的固定 skill/spec 文件名不影响独立运行。打包产物仍未签名，构建测试不代替其他电脑的兼容性测试。许可证见 LICENSE 和 THIRD_PARTY_NOTICES.md。
